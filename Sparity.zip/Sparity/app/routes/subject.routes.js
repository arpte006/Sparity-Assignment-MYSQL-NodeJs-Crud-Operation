module.exports = app => {
    const subjects = require("../controllers/subject.controller.js");
  
    var router = require("express").Router();
  
    //create subject
    router.post("/", subjects.create);
  
    // Retreive all Subjects
    router.get("/", subjects.findAll);
  
    // Retrieve Single Subject with an ID
    router.get("/:id", subjects.findOne);
  
   //Update signle subject with an ID
    router.put("/:id", subjects.update);
  
    app.use('/api/subjects', router);
  };
  
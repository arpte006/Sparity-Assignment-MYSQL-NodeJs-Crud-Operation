module.exports = (sequelize, Sequelize) => {
  const Faculty = sequelize.define("faculty", {
    
    FacultyName: {
      type: Sequelize.STRING
    },
    createdAt: {
      allowNull: false,
      type: Sequelize.DATE
    },
    updatedAt: {
      allowNull: false,
      type: Sequelize.DATE
    }
  })
  return Faculty;
};

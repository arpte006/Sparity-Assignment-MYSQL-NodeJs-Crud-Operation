module.exports = app => {
    const faculty = require("../controllers/faculty.controller.js");
  
    var router = require("express").Router();
  
    // create a new faculty
    router.post("/", faculty.create);
  
    // Retrieve all faculties
    router.get("/", faculty.findAll);
  
    // Retrieve a single faculty with id
    router.get("/:id", faculty.findOne);
  
     // Update a faculty with id
    router.put("/:id", faculty.update);

     // Delete a faculty with id
  router.delete("/:id", faculty.delete);

  // Delete all faculties
  router.delete("/", faculty.deleteAll);
  
    app.use('/api/faculty', router);
  };
  
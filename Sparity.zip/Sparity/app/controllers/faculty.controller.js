const db = require("../models");
const Faculty = db.faculty;
const Op = db.Sequelize.Op;

// Create and Save a new Faculty
exports.create = (req, res) => {
  // Validate request
  if (!req.body.FacultyName) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
    return;
  }

  // Create a Faculty
  const faculty = {
    FacultyName: req.body.FacultyName
  
  };

  // Save Faculty in the database
Faculty.create(faculty)
    .then(data => {
      res.send(data);
    })
    .catch(err => {

      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Faculty."
      });
    });
};


exports.findAll = (req, res) => {
  const FacultyName = req.query.FacultyName;
  var condition = FacultyName ? { FacultyName: { [Op.like]: `%${FacultyName}%` } } : null;

  Faculty.findAll({ where: condition })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving Faculty."
      });
    });
};


exports.findOne = (req, res) => {
  const FacultyId = req.params.id;

  Faculty.findByPk(FacultyId)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving FacultyName with id=" + id
      });
    });
};


exports.update = (req, res) => {
  const FacultyId = req.params.id;

  Faculty.update(req.body, {
    where: { id: FacultyId }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "FacultyName was updated successfully."
        });
      } else {
        res.send({
          message: `Cannot update FacultyName with id=${FacultyId}. Maybe FacultyName was not found or req.body is empty!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error updating FacultyName with id=" + FacultyId
      });
    });
};

// Delete a Faculty with the specified id in the request
exports.delete = (req, res) => {
  const FacultyId = req.params.id;

  Faculty.destroy({
    where: { id: FacultyId }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "Faculty was deleted successfully!"
        });
      } else {
        res.send({
          message: `Cannot delete Faculty with id=${FacultyId}. Maybe Faculty was not found!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Could not delete Faculty with id=" + FacultyId
      });
    });
};

// Delete all Faculties from the database.
exports.deleteAll = (req, res) => {
  Faculty.destroy({
    where: {},
    truncate: false
  })
    .then(nums => {
      res.send({ message: `${nums} All Faculties were deleted successfully!` });
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while removing all Faculties."
      });
    });
};




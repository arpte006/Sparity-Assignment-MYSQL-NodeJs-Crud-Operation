module.exports = (sequelize, Sequelize) => {
  const Student = sequelize.define("student", {
    
    StudentName: {
      type: Sequelize.STRING
    },
    createdAt: {
      allowNull: false,
      type: Sequelize.DATE
    },
    updatedAt: {
      allowNull: false,
      type: Sequelize.DATE
    }
  })
  return Student;
};

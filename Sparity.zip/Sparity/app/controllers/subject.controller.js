const db = require("../models");
const Subject = db.subjects;
const Op = db.Sequelize.Op;

// Create and Save a new Subject
exports.create = (req, res) => {
  // Validate request
  if (!req.body.SubjectName) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
    return;
  }

  // Create a Subject
  const subject = {
    SubjectName: req.body.SubjectName
  
  };

  // Save Subject in the database
  Subject.create(subject)
    .then(data => {
      res.send(data);
    })
    .catch(err => {

      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Subject."
      });
    });
};

// Retrieve all Subjects from the database.
exports.findAll = (req, res) => {
  const SubjectName = req.query.SubjectName;
  var condition = SubjectName ? { SubjectName: { [Op.like]: `%${SubjectName}%` } } : null;

  Subject.findAll({ where: condition })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving Subject."
      });
    });
};

// Find a single Subject with an id
exports.findOne = (req, res) => {
  const SubjectId = req.params.id;

  Subject.findByPk(SubjectId)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving SubjectName with id=" + id
      });
    });
};

// Update a Subject by the id in the request
exports.update = (req, res) => {
  const SubjectId = req.params.id;

  Subject.update(req.body, {
    where: { id: SubjectId }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "SubjectName was updated successfully."
        });
      } else {
        res.send({
          message: `Cannot update SubjectName with id=${SubjectId}. Maybe StudentName was not found or req.body is empty!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error updating SubjectName with id=" + SubjectId
      });
    });
};




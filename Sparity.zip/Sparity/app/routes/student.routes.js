module.exports = app => {
  const students = require("../controllers/student.controller.js");

  var router = require("express").Router();

  //create a new student
  router.post("/", students.create);

  //retrieve all students
  router.get("/", students.findAll);

  //retrieve single student with an id
  router.get("/:id", students.findOne);

 //update student with an id
  router.put("/:id", students.update);

  app.use('/api/students', router);
};

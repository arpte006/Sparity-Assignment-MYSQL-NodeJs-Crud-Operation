const db = require("../models");
const Student = db.students;
const Op = db.Sequelize.Op;

// Create and Save a new Student
exports.create = (req, res) => {
  // Validate request
  if (!req.body.StudentName) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
    return;
  }

  // Create a Student
  const student = {
    StudentName: req.body.StudentName
  
  };

  // Save Student in the database
  Student.create(student)
    .then(data => {
      res.send(data);
    })
    .catch(err => {

      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Student."
      });
    });
};

// Retrieve all Students from the database.
exports.findAll = (req, res) => {
  const StudentName = req.query.StudentName;
  var condition = StudentName ? { StudentName: { [Op.like]: `%${StudentName}%` } } : null;

  Student.findAll({ where: condition })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving Students."
      });
    });
};

// Retrieve a single Student with an id
exports.findOne = (req, res) => {
  const StudentId = req.params.id;

  Student.findByPk(StudentId)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: "Error retrieving StudentName with id=" + id
      });
    });
};

// Update a StudentName by the id in the request
exports.update = (req, res) => {
  const StudentId = req.params.id;

  Student.update(req.body, {
    where: { id: StudentId }
  })
    .then(num => {
      if (num == 1) {
        res.send({
          message: "StudentName was updated successfully."
        });
      } else {
        res.send({
          message: `Cannot update StudentName with id=${StudentId}. Maybe StudentName was not found or req.body is empty!`
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: "Error updating StudentName with id=" + StudentId
      });
    });
};




module.exports = (sequelize, Sequelize) => {
  const Subject = sequelize.define("subject", {
    
    SubjectName: {
      type: Sequelize.STRING
    },
    createdAt: {
      allowNull: false,
      type: Sequelize.DATE
    },
    updatedAt: {
      allowNull: false,
      type: Sequelize.DATE
    }
  })
  return Subject;
};
